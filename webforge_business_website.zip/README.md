# WebForge Business Website

A professional, responsive business website with a built-in customization panel.

## Customize it
Open `index.html` in a browser and click **⚙ Customize Site**.

You can change:
- Business name
- Brand color
- Hero headline and description
- Button text
- Email and phone
- Footer name
- Services heading
- Call-to-action heading

Changes are stored in the browser using localStorage.

## Publish it
Upload `index.html` to any static web host. No server is required for the included customization features.

For a production business site, you can later add:
- Custom domain
- Real contact form/backend
- Analytics
- Portfolio/gallery
- Pricing packages
- Testimonials
- Online booking
- CMS/database
